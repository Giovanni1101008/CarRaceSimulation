public class DistibutoreBenzina {

    private int depositoVerde;
    private int depositoGasolio;
    private int euroPerLitroVerde;
    private int euroPerLitroGasolio;

    public DistibutoreBenzina(int prezzoVerde, int prezzoGasolio) {
        this.depositoVerde = 0;
        this.depositoGasolio = 0;
        this.euroPerLitroVerde = prezzoVerde;
        this.euroPerLitroGasolio = prezzoGasolio;
    }

    public void rifornisciVerde(double litri) {
        depositoVerde += litri;
    }

    public void rifornisciGasolio(double litri) {
        depositoGasolio += litri;
    }

    public synchronized void vendi(Car auto, int euro) throws Exception {
        if (auto.isDiesel("gasolio")) {
            int litri = euro / euroPerLitroGasolio;
            if (litri > depositoGasolio) {
                throw new Exception("Gasolio insufficiente");
            }
            depositoGasolio -= litri;
            auto.addGas(litri);
        } else {
            int litri = euro / euroPerLitroVerde;
            if (litri > depositoVerde) {
                throw new Exception("Benzina verde insufficiente");
            }
            depositoVerde -= litri;
            auto.addGas(litri);
        }
    }

    public void aggiornaPrezzoVerde(int nuovoPrezzo) {
        euroPerLitroVerde = nuovoPrezzo;
    }

    public void aggiornaPrezzoGasolio(int nuovoPrezzo) {
        euroPerLitroGasolio = nuovoPrezzo;
    }
}
